(function () {
  'use strict';

  /* @ngdoc object
   * @name usersList
   * @description
   *
   */
  angular
    .module('usersList', [
      'ui.router',
      'ngAnimate'
    ]);
}());
