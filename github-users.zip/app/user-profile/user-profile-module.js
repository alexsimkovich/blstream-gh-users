(function () {
  'use strict';

  /* @ngdoc object
   * @name userProfile
   * @description
   *
   */
  angular
    .module('userProfile', [
      'ui.router',
      'ngAnimate'
    ]);
}());
